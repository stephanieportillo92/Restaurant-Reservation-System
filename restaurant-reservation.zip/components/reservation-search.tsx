"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { CalendarIcon, Clock, Users } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

export default function ReservationSearch() {
  const router = useRouter()
  const [date, setDate] = useState<Date>()
  const [time, setTime] = useState<string>("")
  const [partySize, setPartySize] = useState<string>("")
  const [isSearching, setIsSearching] = useState(false)

  const availableTimes = [
    "11:00",
    "11:30",
    "12:00",
    "12:30",
    "13:00",
    "13:30",
    "14:00",
    "14:30",
    "17:00",
    "17:30",
    "18:00",
    "18:30",
    "19:00",
    "19:30",
    "20:00",
    "20:30",
    "21:00",
    "21:30",
  ]

  const partySizes = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!date || !time || !partySize) {
      return
    }

    setIsSearching(true)

    try {
      // Format the date and time for the server action
      const formattedDate = format(date, "yyyy-MM-dd")
      const searchParams = new URLSearchParams({
        date: formattedDate,
        time,
        partySize,
      })

      router.push(`/available-tables?${searchParams.toString()}`)
    } catch (error) {
      console.error("Error searching for tables:", error)
    } finally {
      setIsSearching(false)
    }
  }

  return (
    <form onSubmit={handleSearch} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-2">
          <Label htmlFor="date">Date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                id="date"
                variant="outline"
                className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                initialFocus
                disabled={(date) => date < new Date()}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <Label htmlFor="time">Time</Label>
          <Select value={time} onValueChange={setTime}>
            <SelectTrigger id="time" className="w-full">
              <SelectValue placeholder="Select time">
                <div className="flex items-center">
                  {time ? (
                    <>
                      <Clock className="mr-2 h-4 w-4" />
                      {time}
                    </>
                  ) : (
                    "Select time"
                  )}
                </div>
              </SelectValue>
            </SelectTrigger>
            <SelectContent>
              {availableTimes.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="party-size">Party Size</Label>
          <Select value={partySize} onValueChange={setPartySize}>
            <SelectTrigger id="party-size" className="w-full">
              <SelectValue placeholder="Select party size">
                <div className="flex items-center">
                  {partySize ? (
                    <>
                      <Users className="mr-2 h-4 w-4" />
                      {partySize} {Number.parseInt(partySize) === 1 ? "person" : "people"}
                    </>
                  ) : (
                    "Select party size"
                  )}
                </div>
              </SelectValue>
            </SelectTrigger>
            <SelectContent>
              {partySizes.map((size) => (
                <SelectItem key={size} value={size}>
                  {size} {Number.parseInt(size) === 1 ? "person" : "people"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={isSearching || !date || !time || !partySize}>
        {isSearching ? "Searching..." : "Find Available Tables"}
      </Button>
    </form>
  )
}
