import { searchAvailableTables } from "@/lib/actions"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import Link from "next/link"

export default async function AvailableTablesList({
  date,
  time,
  partySize,
}: {
  date: string
  time: string
  partySize: string
}) {
  const tables = await searchAvailableTables(date, time, partySize)

  if (tables.length === 0) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>No tables available</AlertTitle>
        <AlertDescription>
          We couldn't find any available tables for your party size at the requested time. Please try a different time
          or date.
        </AlertDescription>
        <div className="mt-4">
          <Link href="/">
            <Button variant="outline">Try Different Time/Date</Button>
          </Link>
        </div>
      </Alert>
    )
  }

  return (
    <div className="space-y-4">
      {tables.map((option) => (
        <div
          key={option.id}
          className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg hover:bg-stone-50"
        >
          <div className="space-y-2 mb-4 md:mb-0">
            <h3 className="font-medium">
              {option.combinedTables ? "Combined Tables" : `Table for ${option.capacity}`}
            </h3>
            <p className="text-sm text-muted-foreground">
              {option.combinedTables ? `${option.tableDetails}` : `Perfect for your party of ${partySize}`}
            </p>
            {option.isHighTrafficDay && (
              <p className="text-sm text-amber-600 font-medium">* High-traffic day - $10 holding fee required</p>
            )}
          </div>
          <Link
            href={`/reservation-details?date=${date}&time=${time}&partySize=${partySize}&tableOptionId=${option.id}`}
          >
            <Button>Select & Continue</Button>
          </Link>
        </div>
      ))}
    </div>
  )
}
