"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, CreditCard, Info } from "lucide-react"
import { createReservation } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"
import PaymentForm from "@/components/payment-form"

interface TableOption {
  id: string
  capacity: number
  combinedTables: boolean
  tableDetails: string
  isHighTrafficDay: boolean
}

export default function ReservationForm({
  date,
  time,
  partySize,
  tableOption,
}: {
  date: string
  time: string
  partySize: string
  tableOption: TableOption
}) {
  const router = useRouter()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("guest")
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Guest user form state
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [specialRequests, setSpecialRequests] = useState("")
  const [agreeToTerms, setAgreeToTerms] = useState(false)
  const [wantsToRegister, setWantsToRegister] = useState(false)

  // Payment information (for high traffic days)
  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: "",
    cardholderName: "",
    expiryDate: "",
    cvv: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Basic validation
    if (!name || !email || !phone) {
      toast({
        title: "Missing information",
        description: "Please fill out all required fields.",
        variant: "destructive",
      })
      return
    }

    // Validate payment info for high traffic days
    if (tableOption.isHighTrafficDay) {
      if (!paymentInfo.cardNumber || !paymentInfo.cardholderName || !paymentInfo.expiryDate || !paymentInfo.cvv) {
        toast({
          title: "Payment information required",
          description: "Please provide valid payment information for high-traffic day reservations.",
          variant: "destructive",
        })
        return
      }
    }

    if (!agreeToTerms) {
      toast({
        title: "Terms agreement required",
        description: "Please agree to the terms and conditions to continue.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, this would call a server action to create the reservation
      await createReservation({
        date,
        time,
        partySize,
        tableOptionId: tableOption.id,
        guestInfo: {
          name,
          email,
          phone,
          specialRequests,
        },
        paymentInfo: tableOption.isHighTrafficDay ? paymentInfo : undefined,
        userType: activeTab,
        wantsToRegister: activeTab === "guest" && wantsToRegister,
      })

      // Redirect to confirmation page
      router.push(`/reservation-confirmation?reservationId=123456`)
    } catch (error) {
      console.error("Error creating reservation:", error)
      toast({
        title: "Something went wrong",
        description: "We couldn't complete your reservation. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      {tableOption.combinedTables && (
        <Alert className="bg-blue-50 border-blue-200">
          <Info className="h-4 w-4 text-blue-600" />
          <AlertTitle className="text-blue-800">Combined Tables</AlertTitle>
          <AlertDescription className="text-blue-700">
            We'll combine {tableOption.tableDetails} to accommodate your party.
          </AlertDescription>
        </Alert>
      )}

      {tableOption.isHighTrafficDay && (
        <Alert className="bg-amber-50 border-amber-200">
          <AlertCircle className="h-4 w-4 text-amber-600" />
          <AlertTitle className="text-amber-800">High-Traffic Day Notice</AlertTitle>
          <AlertDescription className="text-amber-700">
            This date is in high demand. A $10 holding fee will be charged for no-shows. Valid payment information is
            required to complete this reservation.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="guest" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="guest">Guest Reservation</TabsTrigger>
          <TabsTrigger value="registered">Registered User</TabsTrigger>
        </TabsList>

        <TabsContent value="guest" className="space-y-6 pt-4">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="john@example.com"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(123) 456-7890"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="special-requests">Special Requests (Optional)</Label>
              <textarea
                id="special-requests"
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value)}
                placeholder="Any allergies or special seating preferences?"
                className="w-full min-h-[80px] px-3 py-2 border rounded-md border-input bg-background text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              />
            </div>

            {tableOption.isHighTrafficDay && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center">
                    <CreditCard className="mr-2 h-4 w-4" />
                    Payment Information
                  </CardTitle>
                  <CardDescription>Required for high-traffic day reservations</CardDescription>
                </CardHeader>
                <CardContent>
                  <PaymentForm paymentInfo={paymentInfo} setPaymentInfo={setPaymentInfo} />
                </CardContent>
              </Card>
            )}

            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="register"
                  checked={wantsToRegister}
                  onCheckedChange={(checked) => setWantsToRegister(checked as boolean)}
                />
                <Label htmlFor="register" className="text-sm font-normal">
                  I'd like to register for an account to earn dining points
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="terms"
                  checked={agreeToTerms}
                  onCheckedChange={(checked) => setAgreeToTerms(checked as boolean)}
                  required
                />
                <Label htmlFor="terms" className="text-sm font-normal">
                  I agree to the terms and conditions, including the $10 no-show fee for high-traffic days
                </Label>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? "Processing..." : "Complete Reservation"}
            </Button>
          </form>
        </TabsContent>

        <TabsContent value="registered" className="space-y-6 pt-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="login-email">Email</Label>
              <Input id="login-email" type="email" placeholder="john@example.com" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="login-password">Password</Label>
              <Input id="login-password" type="password" />
            </div>

            <Button className="w-full">Log In</Button>

            <p className="text-sm text-center text-muted-foreground">
              Don't have an account?{" "}
              <Button variant="link" className="p-0 h-auto" onClick={() => setActiveTab("guest")}>
                Continue as guest
              </Button>
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
