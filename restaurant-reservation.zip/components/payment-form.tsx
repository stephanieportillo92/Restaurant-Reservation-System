"use client"

import type React from "react"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface PaymentInfo {
  cardNumber: string
  cardholderName: string
  expiryDate: string
  cvv: string
}

interface PaymentFormProps {
  paymentInfo: PaymentInfo
  setPaymentInfo: React.Dispatch<React.SetStateAction<PaymentInfo>>
}

export default function PaymentForm({ paymentInfo, setPaymentInfo }: PaymentFormProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPaymentInfo((prev) => ({ ...prev, [name]: value }))
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2 md:col-span-2">
        <Label htmlFor="cardNumber">Card Number</Label>
        <Input
          id="cardNumber"
          name="cardNumber"
          placeholder="1234 5678 9012 3456"
          value={paymentInfo.cardNumber}
          onChange={handleChange}
        />
      </div>

      <div className="space-y-2 md:col-span-2">
        <Label htmlFor="cardholderName">Cardholder Name</Label>
        <Input
          id="cardholderName"
          name="cardholderName"
          placeholder="John Doe"
          value={paymentInfo.cardholderName}
          onChange={handleChange}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="expiryDate">Expiry Date</Label>
        <Input
          id="expiryDate"
          name="expiryDate"
          placeholder="MM/YY"
          value={paymentInfo.expiryDate}
          onChange={handleChange}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="cvv">CVV</Label>
        <Input id="cvv" name="cvv" placeholder="123" value={paymentInfo.cvv} onChange={handleChange} />
      </div>
    </div>
  )
}
