import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getUserProfile } from "@/lib/actions"

export default async function UserProfilePage() {
  // In a real app, this would fetch the user profile from the database
  const user = await getUserProfile()

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-stone-800 text-white py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold">Fine Dining Restaurant</h1>
          <p className="text-stone-300 mt-2">Exceptional cuisine in an elegant atmosphere</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>User Profile</CardTitle>
                  <CardDescription>Manage your account details</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Preferred Diner #</p>
                      <p className="text-lg font-bold">{user.preferredDinerNumber}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Earned Points</p>
                      <p className="text-lg font-bold">{user.earnedPoints} points</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Member Since</p>
                      <p>{user.memberSince}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Account Information</CardTitle>
                  <CardDescription>Update your personal details</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="personal">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="personal">Personal</TabsTrigger>
                      <TabsTrigger value="address">Address</TabsTrigger>
                      <TabsTrigger value="payment">Payment</TabsTrigger>
                    </TabsList>

                    <TabsContent value="personal" className="space-y-4 pt-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Full Name</Label>
                          <Input id="name" defaultValue={user.name} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input id="email" type="email" defaultValue={user.email} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="phone">Phone Number</Label>
                          <Input id="phone" defaultValue={user.phone} />
                        </div>
                      </div>
                      <Button>Save Changes</Button>
                    </TabsContent>

                    <TabsContent value="address" className="space-y-4 pt-4">
                      <div className="space-y-4">
                        <div>
                          <h3 className="text-sm font-medium mb-2">Mailing Address</h3>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="street">Street Address</Label>
                              <Input id="street" defaultValue={user.mailingAddress.street} />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="city">City</Label>
                              <Input id="city" defaultValue={user.mailingAddress.city} />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="state">State</Label>
                              <Input id="state" defaultValue={user.mailingAddress.state} />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="zip">ZIP Code</Label>
                              <Input id="zip" defaultValue={user.mailingAddress.zip} />
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox id="same-address" defaultChecked={user.billingAddressSameAsMailing} />
                          <Label htmlFor="same-address">Billing address same as mailing address</Label>
                        </div>

                        {!user.billingAddressSameAsMailing && (
                          <div>
                            <h3 className="text-sm font-medium mb-2">Billing Address</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="billing-street">Street Address</Label>
                                <Input id="billing-street" defaultValue={user.billingAddress.street} />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="billing-city">City</Label>
                                <Input id="billing-city" defaultValue={user.billingAddress.city} />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="billing-state">State</Label>
                                <Input id="billing-state" defaultValue={user.billingAddress.state} />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="billing-zip">ZIP Code</Label>
                                <Input id="billing-zip" defaultValue={user.billingAddress.zip} />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                      <Button>Save Changes</Button>
                    </TabsContent>

                    <TabsContent value="payment" className="space-y-4 pt-4">
                      <div className="space-y-4">
                        <div>
                          <Label className="text-base">Preferred Payment Method</Label>
                          <RadioGroup defaultValue={user.preferredPaymentMethod} className="mt-2">
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="credit" id="credit" />
                              <Label htmlFor="credit">Credit Card</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="cash" id="cash" />
                              <Label htmlFor="cash">Cash</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="check" id="check" />
                              <Label htmlFor="check">Check</Label>
                            </div>
                          </RadioGroup>
                        </div>

                        <div className="pt-2">
                          <h3 className="text-sm font-medium mb-2">Saved Payment Methods</h3>
                          {user.savedPaymentMethods.map((method, index) => (
                            <div key={index} className="flex justify-between items-center p-3 border rounded-md mb-2">
                              <div>
                                <p className="font-medium">
                                  {method.type} ending in {method.last4}
                                </p>
                                <p className="text-sm text-muted-foreground">Expires {method.expiry}</p>
                              </div>
                              <Button variant="outline" size="sm">
                                Remove
                              </Button>
                            </div>
                          ))}
                          <Button variant="outline" className="mt-2">
                            Add Payment Method
                          </Button>
                        </div>
                      </div>
                      <Button>Save Changes</Button>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
