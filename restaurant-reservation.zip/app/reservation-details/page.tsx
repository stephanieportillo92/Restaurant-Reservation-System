import { notFound } from "next/navigation"
import ReservationForm from "@/components/reservation-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getTableOption } from "@/lib/actions"

export default async function ReservationDetailsPage({
  searchParams,
}: {
  searchParams: { date: string; time: string; partySize: string; tableOptionId: string }
}) {
  const { date, time, partySize, tableOptionId } = searchParams

  if (!date || !time || !partySize || !tableOptionId) {
    notFound()
  }

  const tableOption = await getTableOption(tableOptionId)

  if (!tableOption) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-stone-800 text-white py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold">Fine Dining Restaurant</h1>
          <p className="text-stone-300 mt-2">Exceptional cuisine in an elegant atmosphere</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="bg-stone-100">
              <CardTitle className="text-2xl">Complete Your Reservation</CardTitle>
              <CardDescription>
                For {partySize} {Number.parseInt(partySize) === 1 ? "person" : "people"} on {date} at {time}
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ReservationForm date={date} time={time} partySize={partySize} tableOption={tableOption} />
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
