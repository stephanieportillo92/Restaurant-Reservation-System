import Link from "next/link"
import { notFound } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle2 } from "lucide-react"
import { getReservationDetails } from "@/lib/actions"

export default async function ReservationConfirmationPage({
  searchParams,
}: {
  searchParams: { reservationId: string }
}) {
  const { reservationId } = searchParams

  if (!reservationId) {
    notFound()
  }

  // In a real app, this would fetch the reservation details
  const reservation = await getReservationDetails(reservationId)

  if (!reservation) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-stone-800 text-white py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold">Fine Dining Restaurant</h1>
          <p className="text-stone-300 mt-2">Exceptional cuisine in an elegant atmosphere</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="bg-green-50 border-b border-green-100">
              <div className="flex items-center justify-center mb-4">
                <CheckCircle2 className="h-16 w-16 text-green-600" />
              </div>
              <CardTitle className="text-2xl text-center">Reservation Confirmed!</CardTitle>
              <CardDescription className="text-center text-base">
                Your table has been reserved successfully
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Reservation ID</p>
                  <p className="font-medium">{reservation.id}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Status</p>
                  <p className="font-medium text-green-600">Confirmed</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Date</p>
                  <p className="font-medium">{reservation.date}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Time</p>
                  <p className="font-medium">{reservation.time}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Party Size</p>
                  <p className="font-medium">{reservation.partySize} people</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Table</p>
                  <p className="font-medium">{reservation.tableDetails}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground">Reserved For</p>
                  <p className="font-medium">{reservation.name}</p>
                </div>
                {reservation.isHighTrafficDay && (
                  <div className="col-span-2 bg-amber-50 p-3 rounded-md border border-amber-200">
                    <p className="text-amber-800 font-medium">High-Traffic Day Notice</p>
                    <p className="text-amber-700 text-sm">
                      A $10 holding fee will be charged for no-shows on this date.
                    </p>
                  </div>
                )}
              </div>

              {reservation.specialRequests && (
                <div className="border-t pt-4">
                  <p className="text-muted-foreground text-sm">Special Requests</p>
                  <p>{reservation.specialRequests}</p>
                </div>
              )}

              <div className="bg-stone-50 p-4 rounded-md border text-center">
                <p className="text-sm text-stone-600">A confirmation email has been sent to {reservation.email}</p>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <Button className="w-full" asChild>
                <Link href="/">Return to Home</Link>
              </Button>
              {reservation.userType === "guest" && reservation.wantsToRegister && (
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/register">Complete Registration</Link>
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>
      </main>
    </div>
  )
}
