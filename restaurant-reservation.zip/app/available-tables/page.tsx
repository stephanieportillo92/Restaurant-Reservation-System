import { Suspense } from "react"
import { notFound } from "next/navigation"
import AvailableTablesList from "@/components/available-tables-list"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

export default async function AvailableTablesPage({
  searchParams,
}: {
  searchParams: { date: string; time: string; partySize: string }
}) {
  const { date, time, partySize } = searchParams

  if (!date || !time || !partySize) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-stone-800 text-white py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold">Fine Dining Restaurant</h1>
          <p className="text-stone-300 mt-2">Exceptional cuisine in an elegant atmosphere</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="bg-stone-100">
              <CardTitle className="text-2xl">Available Tables</CardTitle>
              <CardDescription>
                For {partySize} {Number.parseInt(partySize) === 1 ? "person" : "people"} on {date} at {time}
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <Suspense fallback={<TablesSkeleton />}>
                <AvailableTablesList date={date} time={time} partySize={partySize} />
              </Suspense>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

function TablesSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
          <div className="space-y-2">
            <Skeleton className="h-5 w-40" />
            <Skeleton className="h-4 w-60" />
          </div>
          <Skeleton className="h-10 w-32" />
        </div>
      ))}
    </div>
  )
}
