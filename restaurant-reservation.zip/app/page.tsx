import ReservationSearch from "@/components/reservation-search"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="min-h-screen bg-stone-50">
      <header className="bg-stone-800 text-white py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold">Fine Dining Restaurant</h1>
          <p className="text-stone-300 mt-2">Exceptional cuisine in an elegant atmosphere</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader className="bg-stone-100">
              <CardTitle className="text-2xl">Reserve Your Table</CardTitle>
              <CardDescription>Find available tables for your party and make a reservation in minutes</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <ReservationSearch />
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
