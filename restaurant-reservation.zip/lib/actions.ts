"use server"

// This file contains server actions for the reservation system
// In a real app, these would interact with a database

// Mock data for demonstration purposes
const tables = [
  { id: "t1", capacity: 2, available: true },
  { id: "t2", capacity: 2, available: true },
  { id: "t3", capacity: 4, available: true },
  { id: "t4", capacity: 4, available: true },
  { id: "t5", capacity: 6, available: true },
  { id: "t6", capacity: 8, available: false },
]

// High traffic days (would be stored in a database)
const highTrafficDays = ["2023-12-24", "2023-12-25", "2023-12-31", "2024-01-01", "2024-07-04"]

export async function searchAvailableTables(date: string, time: string, partySize: string) {
  // Simulate database query delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const size = Number.parseInt(partySize)
  const isHighTrafficDay = highTrafficDays.includes(date)

  // Find available tables that can accommodate the party size
  const availableTables = tables.filter((table) => table.available)

  // Find single tables that can accommodate the party
  const singleTableOptions = availableTables
    .filter((table) => table.capacity >= size)
    .map((table) => ({
      id: `single-${table.id}`,
      capacity: table.capacity,
      combinedTables: false,
      tableDetails: `Table for ${table.capacity}`,
      isHighTrafficDay,
    }))

  // Find combinations of tables that can accommodate the party
  const combinedTableOptions = []

  // Only look for combinations if we need more than 2 people and there's no single table available
  if (size > 2 && singleTableOptions.length === 0) {
    // Simple algorithm to find combinations (in a real app, this would be more sophisticated)
    for (let i = 0; i < availableTables.length; i++) {
      for (let j = i + 1; j < availableTables.length; j++) {
        const combined = availableTables[i].capacity + availableTables[j].capacity
        if (combined >= size) {
          combinedTableOptions.push({
            id: `combined-${availableTables[i].id}-${availableTables[j].id}`,
            capacity: combined,
            combinedTables: true,
            tableDetails: `Table for ${availableTables[i].capacity} + Table for ${availableTables[j].capacity}`,
            isHighTrafficDay,
          })
        }
      }
    }
  }

  // Combine and sort options
  const allOptions = [...singleTableOptions, ...combinedTableOptions]

  // Sort by how well the table fits the party size (minimize wasted seats)
  return allOptions.sort((a, b) => a.capacity - b.capacity)
}

export async function getTableOption(tableOptionId: string) {
  // Simulate database query delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Parse the table option ID to determine if it's a single table or combined tables
  const isCombined = tableOptionId.startsWith("combined-")

  if (isCombined) {
    const [_, tableId1, tableId2] = tableOptionId.split("-")
    const table1 = tables.find((t) => t.id === tableId1)
    const table2 = tables.find((t) => t.id === tableId2)

    if (!table1 || !table2) return null

    return {
      id: tableOptionId,
      capacity: table1.capacity + table2.capacity,
      combinedTables: true,
      tableDetails: `Table for ${table1.capacity} + Table for ${table2.capacity}`,
      isHighTrafficDay: false, // This would be determined by the date in a real app
    }
  } else {
    const tableId = tableOptionId.split("-")[1]
    const table = tables.find((t) => t.id === tableId)

    if (!table) return null

    return {
      id: tableOptionId,
      capacity: table.capacity,
      combinedTables: false,
      tableDetails: `Table for ${table.capacity}`,
      isHighTrafficDay: false, // This would be determined by the date in a real app
    }
  }
}

export async function createReservation(data: any) {
  // Simulate database operation
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // In a real app, this would create a reservation in the database
  console.log("Creating reservation with data:", data)

  // If the user wants to register, we would create a user account here
  if (data.userType === "guest" && data.wantsToRegister) {
    console.log("User wants to register, creating account")
    // Create user account logic would go here
  }

  return { success: true, reservationId: "123456" }
}

export async function getReservationDetails(reservationId: string) {
  // Simulate database query
  await new Promise((resolve) => setTimeout(resolve, 800))

  // Mock reservation data
  return {
    id: reservationId,
    date: "May 15, 2024",
    time: "19:00",
    partySize: "4",
    tableDetails: "Table for 4",
    name: "John Doe",
    email: "john@example.com",
    phone: "(123) 456-7890",
    specialRequests: "Window seat if possible",
    isHighTrafficDay: true,
    userType: "guest",
    wantsToRegister: true,
  }
}

export async function getUserProfile() {
  // Simulate database query
  await new Promise((resolve) => setTimeout(resolve, 800))

  // Mock user data
  return {
    id: "user123",
    name: "John Doe",
    email: "john@example.com",
    phone: "(123) 456-7890",
    preferredDinerNumber: "PD12345",
    earnedPoints: 250,
    memberSince: "January 15, 2023",
    mailingAddress: {
      street: "123 Main St",
      city: "Anytown",
      state: "CA",
      zip: "12345",
    },
    billingAddressSameAsMailing: true,
    billingAddress: {
      street: "123 Main St",
      city: "Anytown",
      state: "CA",
      zip: "12345",
    },
    preferredPaymentMethod: "credit",
    savedPaymentMethods: [
      {
        type: "Visa",
        last4: "4242",
        expiry: "05/25",
      },
      {
        type: "Mastercard",
        last4: "8888",
        expiry: "09/24",
      },
    ],
  }
}
